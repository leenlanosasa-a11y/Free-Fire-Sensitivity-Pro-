# Free Fire Sensitivity Pro

An unofficial Flutter starter app for Android. The current build is a basic sensitivity slider demo. Device-specific recommendations, live AI, image analysis, and game data integrations are not connected yet.

## Build
Run `flutter pub get`, then `flutter build apk --release`.

This project is not affiliated with or endorsed by Garena.
