import 'package:flutter/material.dart';

void main() => runApp(const SensitivityApp());

class SensitivityApp extends StatelessWidget {
  const SensitivityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Free Fire Sensitivity Pro',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090711),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B4DFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final values = <String, double>{
  };

  @override
  Widget build(BuildContext context) {
    final settings = <String, double>{
      'General': 165,
      'Red Dot': 150,
      '2X Scope': 145,
      '4X Scope': 135,
      'Sniper Scope': 80,
      'Free Look': 120,
    };
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sensitivity Pro'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('FREE FIRE', style: TextStyle(
            fontSize: 13, letterSpacing: 3, color: Color(0xFFB88AFF))),
          const SizedBox(height: 8),
          const Text('Sensitivity Assistant',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Starter settings — adjust them in Training Ground. '
              'These are suggestions, not guaranteed results.'),
          const SizedBox(height: 20),
          ...settings.entries.map((entry) => Card(
            color: const Color(0xFF171323),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(child: Text(entry.key,
                        style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text(entry.value.toInt().toString(),
                        style: const TextStyle(color: Color(0xFFC69BFF))),
                  ]),
                  Slider(
                    min: 0,
                    max: 200,
                    value: entry.value,
                    onChanged: (v) => setState(() => settings[entry.key] = v),
                  ),
                ],
              ),
            ),
          )),
          const SizedBox(height: 12),
          const Card(
            color: Color(0xFF21162E),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Unofficial fan-made helper. Not affiliated with Garena. '
                  'Sensitivity varies by device, game version, and personal preference.'),
            ),
          ),
        ],
      ),
    );
  }
}
